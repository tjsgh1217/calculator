import { DynamoDBService } from '../dynamodb/dynamodb.service';
import { User } from './entities/user.entity';
import { JwtService } from '@nestjs/jwt';
export declare class UsersService {
    private readonly dynamoDBService;
    private readonly jwtService;
    private readonly tableName;
    private readonly USER_RECORD_TYPE;
    private readonly validEmailDomains;
    private readonly saltRounds;
    constructor(dynamoDBService: DynamoDBService, jwtService: JwtService);
    private validateId;
    private validateName;
    private validatePassword;
    private validateEmailDomain;
    create(createUserDto: {
        email: string;
        name: string;
        id: string;
        password: string;
    }): Promise<User | {
        error: string;
    }>;
    findAll(): Promise<User[]>;
    findOne(userId: string): Promise<User | null>;
    findById(id: string): Promise<User | null>;
    findByName(name: string): Promise<User | null>;
    findByEmail(email: string): Promise<User | null>;
    validateUser(id: string, password: string): Promise<User | null>;
    update(userId: string, updateUserDto: Partial<User>): Promise<User | null>;
    remove(userId: string): Promise<void>;
    changePassword(userId: string, currentPassword: string, newPassword: string): Promise<{
        success: boolean;
        message: string;
    }>;
    login(id: string, password: string): Promise<{
        access_token?: string;
        user?: User;
    }>;
    private mapToUser;
}
