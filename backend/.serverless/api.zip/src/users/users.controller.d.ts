import { Request } from 'express';
import { UsersService } from './users.service';
import { User } from './entities/user.entity';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    login(loginDto: {
        id: string;
        password: string;
    }): Promise<{
        success: boolean;
        access_token?: string;
        user?: User;
    }>;
    create(createUserDto: {
        email: string;
        name: string;
        id: string;
        password: string;
    }): Promise<User | {
        error: string;
        userId?: undefined;
    }>;
    changePassword(passwordData: {
        currentPassword: string;
        newPassword: string;
    }, req: Request): Promise<{
        success: boolean;
        message: string;
        requireRelogin?: boolean;
    }>;
    findAll(): Promise<User[]>;
    getProfile(req: Request): {
        isLoggedIn: boolean;
        user: Express.User | undefined;
    };
    findOne(userId: string): Promise<User | null>;
    update(userId: string, updateUserDto: Partial<User>): Promise<User | null>;
    remove(userId: string): Promise<{
        message: string;
    }>;
}
