"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const dynamodb_service_1 = require("../dynamodb/dynamodb.service");
const bcryptjs = __importStar(require("bcryptjs"));
const jwt_1 = require("@nestjs/jwt");
let UsersService = class UsersService {
    constructor(dynamoDBService, jwtService) {
        this.dynamoDBService = dynamoDBService;
        this.jwtService = jwtService;
        this.tableName = 'cal_table';
        this.USER_RECORD_TYPE = 'USER';
        this.validEmailDomains = [
            'gmail.com',
            'naver.com',
            'daum.net',
            'kakao.com',
            'nate.com',
        ];
        this.saltRounds = 10;
    }
    validateId(id) {
        if (!id || id.trim() === '') {
            return { isValid: false, error: 'ID를 입력해주세요.' };
        }
        const idRegex = /^[a-zA-Z][a-zA-Z0-9]*$/;
        if (!idRegex.test(id)) {
            return {
                isValid: false,
                error: 'ID는 영문자로 시작해야 하며, 영문자와 숫자만 포함할 수 있습니다.',
            };
        }
        return { isValid: true };
    }
    validateName(name) {
        if (!name || name.trim() === '') {
            return { isValid: false, error: '이름을 입력해주세요.' };
        }
        const nameRegex = /^[가-힣a-zA-Z]+$/;
        if (!nameRegex.test(name)) {
            return {
                isValid: false,
                error: '이름은 한글 또는 영문만 입력 가능합니다.',
            };
        }
        return { isValid: true };
    }
    validatePassword(password) {
        if (!password || password.length < 8) {
            return {
                isValid: false,
                error: '비밀번호는 최소 8자 이상이어야 합니다.',
            };
        }
        const hasLetter = /[a-zA-Z]/.test(password);
        const hasNumber = /\d/.test(password);
        const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
        if (!hasLetter || !hasNumber || !hasSpecial) {
            return {
                isValid: false,
                error: '비밀번호는 영문, 숫자, 특수문자를 모두 포함해야 합니다.',
            };
        }
        return { isValid: true };
    }
    validateEmailDomain(email) {
        if (!email || !email.includes('@')) {
            return { isValid: false, error: '유효하지 않은 이메일 형식입니다.' };
        }
        const localPart = email.split('@')[0];
        const localPartRegex = /^[a-zA-Z][a-zA-Z0-9]*$/;
        if (!localPartRegex.test(localPart)) {
            return {
                isValid: false,
                error: '이메일은 영문자로 시작해야 하며, 영문자와 숫자만 포함할 수 있습니다.',
            };
        }
        const domain = email.split('@')[1];
        if (!this.validEmailDomains.includes(domain)) {
            return { isValid: false, error: '지원하지 않는 이메일 도메인입니다.' };
        }
        return { isValid: true };
    }
    async create(createUserDto) {
        const idValidation = this.validateId(createUserDto.id);
        if (!idValidation.isValid) {
            return {
                error: idValidation.error || 'ID 검증에 실패했습니다.',
            };
        }
        const passwordValidation = this.validatePassword(createUserDto.password);
        if (!passwordValidation.isValid) {
            return {
                error: passwordValidation.error || '비밀번호 검증에 실패했습니다.',
            };
        }
        const nameValidation = this.validateName(createUserDto.name);
        if (!nameValidation.isValid) {
            return {
                error: nameValidation.error || '이름 검증에 실패했습니다.',
            };
        }
        const emailValidation = this.validateEmailDomain(createUserDto.email);
        if (!emailValidation.isValid) {
            return {
                error: emailValidation.error || '이메일 검증에 실패했습니다.',
            };
        }
        try {
            const existingUsers = await this.findAll();
            const duplicateEmail = existingUsers.find((user) => user.email === createUserDto.email);
            if (duplicateEmail) {
                return { error: '이미 사용 중인 이메일입니다.' };
            }
            const duplicateId = existingUsers.find((user) => user.id === createUserDto.id);
            if (duplicateId) {
                return { error: '이미 사용 중인 ID입니다.' };
            }
            const now = new Date();
            const kstTime = new Date(now.getTime() + 9 * 60 * 60 * 1000);
            const hashedPassword = await bcryptjs.hash(createUserDto.password, this.saltRounds);
            const newUser = {
                userId: crypto.randomUUID(),
                calcId: this.USER_RECORD_TYPE,
                name: createUserDto.name,
                email: createUserDto.email,
                id: createUserDto.id,
                password: hashedPassword,
                createdAt: kstTime,
            };
            const userForDb = {
                ...newUser,
                createdAt: kstTime.toISOString(),
            };
            await this.dynamoDBService.put(this.tableName, userForDb);
            return newUser;
        }
        catch (error) {
            console.error('사용자 생성 실패:', error);
            return { error: '회원가입 중 오류가 발생했습니다.' };
        }
    }
    async findAll() {
        const result = await this.dynamoDBService.scan(this.tableName);
        return (result.Items || [])
            .filter((item) => item.calcId === this.USER_RECORD_TYPE)
            .map((item) => this.mapToUser(item));
    }
    async findOne(userId) {
        const result = await this.dynamoDBService.get(this.tableName, userId, this.USER_RECORD_TYPE);
        return result.Item ? this.mapToUser(result.Item) : null;
    }
    async findById(id) {
        const users = await this.findAll();
        const user = users.find((user) => user.id === id);
        return user || null;
    }
    async findByName(name) {
        const users = await this.findAll();
        const user = users.find((user) => user.name === name);
        return user || null;
    }
    async findByEmail(email) {
        const users = await this.findAll();
        const user = users.find((user) => user.email === email);
        return user || null;
    }
    async validateUser(id, password) {
        const user = await this.findById(id);
        if (!user) {
            return null;
        }
        const isPasswordValid = await bcryptjs.compare(password, user.password);
        return isPasswordValid ? user : null;
    }
    async update(userId, updateUserDto) {
        if (updateUserDto.name) {
            const nameValidation = this.validateName(updateUserDto.name);
            if (!nameValidation.isValid) {
                throw new Error(nameValidation.error || '이름 검증에 실패했습니다.');
            }
        }
        if (updateUserDto.id) {
            const idValidation = this.validateId(updateUserDto.id);
            if (!idValidation.isValid) {
                throw new Error(idValidation.error || 'ID 검증에 실패했습니다.');
            }
        }
        if (updateUserDto.email) {
            const emailValidation = this.validateEmailDomain(updateUserDto.email);
            if (!emailValidation.isValid) {
                throw new Error(emailValidation.error || '이메일 검증에 실패했습니다.');
            }
        }
        if (updateUserDto.password) {
            const passwordValidation = this.validatePassword(updateUserDto.password);
            if (!passwordValidation.isValid) {
                throw new Error(passwordValidation.error || '비밀번호 검증에 실패했습니다.');
            }
        }
        const updateExpression = Object.keys(updateUserDto)
            .map((k, i) => `#key${i} = :value${i}`)
            .join(', ');
        const expressionAttributeNames = Object.keys(updateUserDto).reduce((acc, k, i) => ({
            ...acc,
            [`#key${i}`]: k,
        }), {});
        const expressionAttributeValues = Object.keys(updateUserDto).reduce((acc, k, i) => ({
            ...acc,
            [`:value${i}`]: updateUserDto[k],
        }), {});
        const result = await this.dynamoDBService.update(this.tableName, userId, this.USER_RECORD_TYPE, `SET ${updateExpression}`, expressionAttributeValues, expressionAttributeNames);
        return result.Attributes ? this.mapToUser(result.Attributes) : null;
    }
    async remove(userId) {
        try {
            const result = await this.dynamoDBService.query(this.tableName, 'userId = :userId', { ':userId': userId });
            const items = result.Items || [];
            const deletePromises = items
                .filter((item) => item.calcId !== this.USER_RECORD_TYPE)
                .map((item) => this.dynamoDBService.delete(this.tableName, item.userId, item.calcId));
            if (deletePromises.length > 0) {
                await Promise.all(deletePromises);
            }
            await this.dynamoDBService.delete(this.tableName, userId, this.USER_RECORD_TYPE);
            console.log(`사용자(${userId})와 관련된 모든 데이터가 삭제되었습니다.`);
        }
        catch (error) {
            console.error(`사용자 및 관련 데이터 삭제 중 오류 발생 (userId: ${userId}):`, error);
            throw error;
        }
    }
    async changePassword(userId, currentPassword, newPassword) {
        try {
            const user = await this.findOne(userId);
            if (!user) {
                return { success: false, message: '사용자를 찾을 수 없습니다.' };
            }
            const isPasswordValid = await bcryptjs.compare(currentPassword, user.password);
            if (!isPasswordValid) {
                return {
                    success: false,
                    message: '현재 비밀번호가 일치하지 않습니다.',
                };
            }
            const passwordValidation = this.validatePassword(newPassword);
            if (!passwordValidation.isValid) {
                return {
                    success: false,
                    message: passwordValidation.error || '비밀번호 검증에 실패했습니다.',
                };
            }
            const hashedNewPassword = await bcryptjs.hash(newPassword, this.saltRounds);
            await this.update(userId, { password: hashedNewPassword });
            return {
                success: true,
                message: '비밀번호가 성공적으로 변경되었습니다.',
            };
        }
        catch (error) {
            console.error('비밀번호 변경 중 오류 발생:', error);
            return {
                success: false,
                message: '비밀번호 변경 중 오류가 발생했습니다.',
            };
        }
    }
    async login(id, password) {
        const user = await this.validateUser(id, password);
        if (!user) {
            return {};
        }
        const payload = { sub: user.userId, username: user.name };
        const access_token = this.jwtService.sign(payload);
        const { password: _, ...result } = user;
        return {
            access_token,
            user: result,
        };
    }
    mapToUser(item) {
        return {
            userId: String(item.userId),
            calcId: String(item.calcId),
            name: String(item.name),
            email: String(item.email),
            id: String(item.id || ''),
            password: String(item.password || ''),
            createdAt: new Date(item.createdAt),
        };
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [dynamodb_service_1.DynamoDBService,
        jwt_1.JwtService])
], UsersService);
//# sourceMappingURL=users.service.js.map