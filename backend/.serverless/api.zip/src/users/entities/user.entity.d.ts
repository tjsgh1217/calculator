export declare class User {
    userId: string;
    calcId: string;
    name: string;
    email: string;
    createdAt: Date | string;
    password: string;
    id: string;
}
