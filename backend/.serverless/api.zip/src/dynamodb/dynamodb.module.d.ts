export declare class DynamoDBModule {
}
