export declare class DynamoDBService {
    private readonly docClient;
    constructor();
    put(tableName: string, item: Record<string, any>): Promise<import("@aws-sdk/lib-dynamodb").PutCommandOutput>;
    get(tableName: string, userId: string, calcId: string): Promise<import("@aws-sdk/lib-dynamodb").GetCommandOutput>;
    scan(tableName: string, options?: any): Promise<import("@aws-sdk/lib-dynamodb").ScanCommandOutput>;
    update(tableName: string, userId: string, calcId: string, updateExpression: string, expressionAttributeValues: Record<string, any>, expressionAttributeNames?: Record<string, string>): Promise<import("@aws-sdk/lib-dynamodb").UpdateCommandOutput>;
    delete(tableName: string, userId: string, calcId: string): Promise<import("@aws-sdk/lib-dynamodb").DeleteCommandOutput>;
    query(tableName: string, keyConditionExpression: string, expressionAttributeValues: Record<string, any>): Promise<import("@aws-sdk/lib-dynamodb").QueryCommandOutput>;
}
