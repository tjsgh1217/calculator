import { Request, Response } from 'express';
import { CalculationsService } from './calculations/calculations.service';
export declare class AppController {
    private readonly calculationsService;
    constructor(calculationsService: CalculationsService);
    getSignupPage(): {
        message: string;
        path: string;
        user: null;
        isLoggedIn: boolean;
    };
    getLoginPage(): {
        message: string;
        path: string;
        user: null;
        isLoggedIn: boolean;
    };
    root(): {
        message: string;
        path: string;
        user: null;
        isLoggedIn: boolean;
    };
    getMyPage(req: Request): {
        message: string;
        path: string;
        user: Express.User | undefined;
        isLoggedIn: boolean;
    };
    logout(res: Response): void;
    getHistoryPage(req: Request): Promise<{
        message: string;
        path: string;
        user: string;
        isLoggedIn: boolean;
        history: {
            expression: string;
            result: string;
            createdAt: Date;
        }[];
    }>;
}
