"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppController = void 0;
const common_1 = require("@nestjs/common");
const calculations_service_1 = require("./calculations/calculations.service");
const jwt_auth_guard_1 = require("./users/jwt-auth.guard");
let AppController = class AppController {
    constructor(calculationsService) {
        this.calculationsService = calculationsService;
    }
    getSignupPage() {
        return {
            message: 'Signup Page',
            path: '/signup',
            user: null,
            isLoggedIn: false,
        };
    }
    getLoginPage() {
        return {
            message: 'Login Page',
            path: '/login',
            user: null,
            isLoggedIn: false,
        };
    }
    root() {
        return {
            message: 'test',
            path: '/',
            user: null,
            isLoggedIn: false,
        };
    }
    getMyPage(req) {
        return {
            message: 'My Page',
            path: '/mypage',
            user: req.user,
            isLoggedIn: true,
        };
    }
    logout(res) {
        res.redirect('/');
    }
    async getHistoryPage(req) {
        let history = [];
        try {
            const user = req.user;
            if (user && user.sub) {
                history = await this.calculationsService.getCalculationHistory(user.sub);
            }
        }
        catch (error) {
            console.error('Error fetching calculation history:', error instanceof Error ? error.message : error);
        }
        return {
            message: 'Calculation History',
            path: '/history',
            user: req.user,
            isLoggedIn: true,
            history,
        };
    }
};
exports.AppController = AppController;
__decorate([
    (0, common_1.Get)('signup'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AppController.prototype, "getSignupPage", null);
__decorate([
    (0, common_1.Get)('login'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AppController.prototype, "getLoginPage", null);
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], AppController.prototype, "root", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('mypage'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AppController.prototype, "getMyPage", null);
__decorate([
    (0, common_1.Get)('logout'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AppController.prototype, "logout", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AppController.prototype, "getHistoryPage", null);
exports.AppController = AppController = __decorate([
    (0, common_1.Controller)(),
    __metadata("design:paramtypes", [calculations_service_1.CalculationsService])
], AppController);
//# sourceMappingURL=app.controller.js.map