"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalculationsController = void 0;
const common_1 = require("@nestjs/common");
const calculations_service_1 = require("./calculations.service");
const uuid_1 = require("uuid");
const jwt_auth_guard_1 = require("../users/jwt-auth.guard");
let CalculationsController = class CalculationsController {
    constructor(calculationsService) {
        this.calculationsService = calculationsService;
    }
    async saveCalculation(data, req) {
        try {
            const user = req.user;
            if (!user || !user.userId) {
                return { success: false, message: '사용자 ID를 찾을 수 없습니다' };
            }
            const calcId = (0, uuid_1.v4)();
            await this.calculationsService.saveCalculation({
                userId: user.userId,
                calcId,
                expression: data.expression,
                result: data.result,
                createdAt: new Date(),
            });
            return { success: true };
        }
        catch (error) {
            return {
                success: false,
                message: error instanceof Error
                    ? error.message
                    : '계산 기록 저장 중 오류가 발생했습니다',
            };
        }
    }
    async getHistory(req) {
        try {
            const user = req.user;
            if (!user || !user.userId) {
                return { success: false, message: '사용자 ID를 찾을 수 없습니다' };
            }
            const history = await this.calculationsService.getCalculationHistory(user.userId);
            return { success: true, history };
        }
        catch (error) {
            return {
                success: false,
                message: error instanceof Error
                    ? error.message
                    : '계산 기록 조회 중 오류가 발생했습니다',
            };
        }
    }
    async deleteCalculation(calcId, req) {
        try {
            const user = req.user;
            if (!user || !user.userId) {
                return { success: false, message: '사용자 ID를 찾을 수 없습니다' };
            }
            await this.calculationsService.deleteCalculation(user.userId, calcId);
            return { success: true, message: '계산 기록이 삭제되었습니다' };
        }
        catch (error) {
            console.error('계산 기록 삭제 중 오류:', error);
            return {
                success: false,
                message: error instanceof Error
                    ? error.message
                    : '계산 기록 삭제 중 오류가 발생했습니다',
            };
        }
    }
};
exports.CalculationsController = CalculationsController;
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('save'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], CalculationsController.prototype, "saveCalculation", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CalculationsController.prototype, "getHistory", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Delete)('delete/:calcId'),
    __param(0, (0, common_1.Param)('calcId')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], CalculationsController.prototype, "deleteCalculation", null);
exports.CalculationsController = CalculationsController = __decorate([
    (0, common_1.Controller)('calculations'),
    __metadata("design:paramtypes", [calculations_service_1.CalculationsService])
], CalculationsController);
//# sourceMappingURL=calculations.controller.js.map