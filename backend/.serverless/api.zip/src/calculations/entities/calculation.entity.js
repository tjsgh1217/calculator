"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Calculation = void 0;
class Calculation {
}
exports.Calculation = Calculation;
//# sourceMappingURL=calculation.entity.js.map