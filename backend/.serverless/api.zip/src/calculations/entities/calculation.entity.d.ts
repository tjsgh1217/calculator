export declare class Calculation {
    userId: string;
    calcId: string;
    expression: string;
    result: string;
    createdAt: Date;
}
