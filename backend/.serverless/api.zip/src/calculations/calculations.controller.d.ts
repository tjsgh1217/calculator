import { Request } from 'express';
import { CalculationsService } from './calculations.service';
export declare class CalculationsController {
    private readonly calculationsService;
    constructor(calculationsService: CalculationsService);
    saveCalculation(data: {
        expression: string;
        result: string;
    }, req: Request): Promise<{
        success: boolean;
        message?: string;
    }>;
    getHistory(req: Request): Promise<any>;
    deleteCalculation(calcId: string, req: Request): Promise<{
        success: boolean;
        message?: string;
    }>;
}
