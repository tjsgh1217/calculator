import { DynamoDBService } from '../dynamodb/dynamodb.service';
export declare class CalculationsService {
    private readonly dynamoDBService;
    private readonly tableName;
    constructor(dynamoDBService: DynamoDBService);
    saveCalculation(calculationData: {
        userId: string;
        calcId: string;
        expression: string;
        result: string;
        createdAt: Date;
    }): Promise<void>;
    getCalculationHistory(userId: string): Promise<{
        calcId: string;
        expression: string;
        result: string;
        createdAt: Date;
    }[]>;
    deleteCalculation(userId: string, calcId: string): Promise<void>;
}
