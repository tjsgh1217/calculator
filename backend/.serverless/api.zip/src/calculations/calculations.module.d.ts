export declare class CalculationsModule {
}
