"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalculationsService = void 0;
const common_1 = require("@nestjs/common");
const dynamodb_service_1 = require("../dynamodb/dynamodb.service");
let CalculationsService = class CalculationsService {
    constructor(dynamoDBService) {
        this.dynamoDBService = dynamoDBService;
        this.tableName = 'cal_table';
    }
    async saveCalculation(calculationData) {
        try {
            const kstDate = new Date(calculationData.createdAt);
            kstDate.setHours(kstDate.getHours() + 9);
            const calculationDataWithISODate = {
                ...calculationData,
                createdAt: kstDate.toISOString(),
            };
            await this.dynamoDBService.put(this.tableName, calculationDataWithISODate);
        }
        catch (error) {
            console.error('계산을 저장하는 중 오류 발생:', error);
            throw new Error('DynamoDB에 계산을 저장하는데 실패');
        }
    }
    async getCalculationHistory(userId) {
        try {
            const result = await this.dynamoDBService.scan(this.tableName, {
                FilterExpression: 'userId = :userId',
                ExpressionAttributeValues: {
                    ':userId': userId,
                },
            });
            return result.Items
                ? result.Items.map((item) => {
                    const incorrectDate = new Date(item.createdAt);
                    const correctedDate = new Date(incorrectDate.getTime() - 9 * 60 * 60 * 1000);
                    return {
                        calcId: item.calcId,
                        expression: item.expression,
                        result: item.result,
                        createdAt: correctedDate,
                    };
                })
                    .filter((item) => item.expression && item.result)
                    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
                : [];
        }
        catch (error) {
            console.error('계산 기록을 가져오는 중 오류 발생:', error);
            throw new Error('계산 기록을 가져오는데 실패');
        }
    }
    async deleteCalculation(userId, calcId) {
        try {
            await this.dynamoDBService.delete(this.tableName, userId, calcId);
            console.log(`계산 기록 삭제 성공: ${calcId}`);
        }
        catch (error) {
            console.error('계산 기록을 삭제하는 중 오류 발생:', error);
            throw new Error('DynamoDB에서 계산 기록을 삭제하는데 실패');
        }
    }
};
exports.CalculationsService = CalculationsService;
exports.CalculationsService = CalculationsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [dynamodb_service_1.DynamoDBService])
], CalculationsService);
//# sourceMappingURL=calculations.service.js.map